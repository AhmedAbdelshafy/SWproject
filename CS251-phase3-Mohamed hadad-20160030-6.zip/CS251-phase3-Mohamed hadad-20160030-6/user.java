import java.util.Vector;
import java.util.*;
public class user {

    public String username;

    public String password;


    /**
     *
     * @element-type PAGE
     */
    public Vector  follow;
    /**
     *
     * @element-type group
     */
    public Vector  join;
    /**
     *
     * @element-type post
     */
    public Vector  makes;

    public Vector  creates;

   public static Map<String, String> dataBase = new HashMap<String, String>();
   public  static Scanner input = new Scanner(System.in);

    public static void signup() {
        System.out.println("enter your username and your password for signig up");
        String user = input.nextLine();
        String pass = input.nextLine();
        dataBase.put(user, pass);

    }

    public static void login() {
        System.out.println("enter your username and your password for logging in");
        String user = input.nextLine();
        String pass = input.nextLine();
        if(dataBase.containsKey(user) && dataBase.containsValue(pass))
            System.out.println("you are logged in");

        else
            System.out.println("wrong username or password");
    }
public class person {
      private  String name ;
      private ArrayList<String>friends ;
      private final String sperator= "" ;
      
      public person(String name){
          this.name= name ;
          this.friends= new  ArrayList<>() ;
      }
      

  public void addFriend(person friend) {
  
    friends.add(friend.name);
       
  }
  public String confirmFriend(){
    String allFriends =friends.toString();
    return allFriends.substring(1,allFriends.length()-1);
    }
    private String confirmFriend(int friendIndex) {
        return friends.get(friendIndex);
  }
  }
   public static void main(String[] args) {
        signup();
        login();
    }

}