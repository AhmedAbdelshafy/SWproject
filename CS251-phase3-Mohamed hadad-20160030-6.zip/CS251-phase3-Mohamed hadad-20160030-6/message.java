
import software.Software.user;

public class message {

  public String type;

    public user creates;
    public apiController control;

  public void sendMessage() {
  }

  public void recieveMessage() {
  }

}