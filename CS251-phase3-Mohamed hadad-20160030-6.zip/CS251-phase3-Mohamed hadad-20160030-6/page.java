import java.util.Vector;

public class page {

  public String name;

  public int followers;

    /**
   * 
   * @element-type user
   */
  public Vector  follow;
    public apiController control;

  public void follow() {
  }

}