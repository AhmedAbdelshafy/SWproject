import java.util.Vector;

public class group {

  public String name;

  public int members;

    /**
   * 
   * @element-type user
   */
  public Vector  join;
    /**
   * 
   * @element-type post
   */
  public Vector  has;
    public apiController control;

  public boolean isVisible() {
  return false;
  }

}