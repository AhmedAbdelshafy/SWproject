import java.util.Vector;

public class apiController {

   
  public Vector  control;
   

  private void controlGroup() {
  }

  public void controlPage() {
  }

  public void controlPost() {
  }

  public void controlComment() {
  }

  public void controlMessage() {
  }

 
}