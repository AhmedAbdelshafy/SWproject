
import software.Software.user;

public class comment {

  public String type;

   //
    public user makes;
    public apiController control;

  public void comment() {
  }

  public void like() {
  }

}