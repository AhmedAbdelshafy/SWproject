
import software.Software.user;

public class admin extends user {

  public void adminGroup() {
  }

  public void adminPage() {
  }

}