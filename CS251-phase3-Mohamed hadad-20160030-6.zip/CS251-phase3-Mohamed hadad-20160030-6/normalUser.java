
import software.Software.user;

public class normalUser extends user {
}