import java.util.Vector;
import software.Software.user;

public class post {

  public String type;

    /**
   * 
   * @element-type comment
   */
    public user makes;
    public apiController control;

  public void Post() {
  }

  public void share() {
  }

  public void like() {
  }

}